# from setuptools import setup
from distutils.core import setup

setup(
    name='python-learning',
    version='1.0.0',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
    url='https://hogehoge.com',
    license='',
    author='yusuke_n',
    author_email='',
    description=''
)
