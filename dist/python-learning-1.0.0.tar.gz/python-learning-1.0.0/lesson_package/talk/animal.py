def sing():
    return 'djaljfoiajeia'


def cry():
    return 'dafjsidoahif'