def say_third(word):
    return (word + '!') * 3